		
	
	</div><!-- termina caja principal -->
	
	<footer class="footer"> <!-- inicia Footer -->
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/form.js"></script>
	</footer>
	<!-- termina Footer -->
	</body>
</html>