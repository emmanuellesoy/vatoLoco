<div class="contacto" id="contacto">


	<div class="tituloSecciones">
		<div class="tituloContacto">Contacto</div>	
	</div>

		<div class="mapa"></div>

		<div class="infoContacto">
			<div class="formulario">
				<h4>CONTACTANOS!</h4>

				<form method="post">
                    <input class="campos camposmitad" id="nombre" name="nombre" type=" text" placeholder="nombre" required="required">
                    <input class="campos camposmitad" id="email" name="email" type="email" placeholder="correo" required="required">
                    <p>
                    <input class="campos camposCompleto" id="asunto" name="asunto" type="text" placeholder="asunto" required="required">
                    <textarea class="campos camposCompleto" id="mensaje" name="mensaje" cols="43" rows="1" placeholder="mensaje" required="required"></textarea>
                    <div class="enviar">
                           <div class="ultimo">
                                    <img src="<?php bloginfo( 'template_directory' ); ?>/img/loading.gif" class="ajaxgif hide" />
                                    <div class="msg"></div>
                                    <button class="boton">enviar</button>
                            </div>
                    </div>
                </form>
			</div>

			<div class="datosContacto">
				<h4>DIRECCIÓN</h4>
					<div class="informacion">
						<h3>LOS CHOLOS</h3>
						<p>CALLE</p>
						<p>COLONIA</p>
						<p>DEL CP</p>
						<p>TELEDONO</p>
						<p>E MAIL</p>
					</div>
					<div class="redes">
						 <a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/img/twitterC.png"/></a>
						 <a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/img/facebookC.png"/></a>
						 <a href="#"><img src="<?php bloginfo( 'template_directory' ); ?>/img/plusC.png"/></a>
						 <a href="#"> <img src="<?php bloginfo( 'template_directory' ); ?>/img/pinterestC.png"/></a>
					</div>
			</div> 	<!-- Termina Datos COntacto -->
	  </div> <!-- Termina Info  COntacto -->

<div class="derechos">
				<img src="<?php bloginfo( 'template_directory' ); ?>/img/logo_pie.png"/>
			</div>

</div>