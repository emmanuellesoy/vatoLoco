 <header>
    <nav class="menu" id="menu">
        <ul>
            <li class="menuInicio">
               <a href="#inicio" title="Inicio"><h4>INICIO</h4></a>             
            </li> 
            <li class="menuProyectos">
                <a href="#proyectos" title="Inicio"><h4>PROYECTOS</h4></a>
            </li> 
            <li>
                <a href="<?php bloginfo('wpurl'); ?>" title="#">
                <img src="<?php bloginfo('template_url'); ?>/img/logo.png" title="#" alt="#"/></a>
            </li>
            <li class="menuEquipo">
                <a href="#equipo" title="Inicio"><h4>EQUIPO</h4></a>
            </li> 
            <li class="menuContacto">
                <a href="#contacto" title="Inicio"><h4>CONTACTO</h4></a>
            </li> 
        </ul>
    </nav>
</header>