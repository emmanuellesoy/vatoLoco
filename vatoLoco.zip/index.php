<?php get_header()?>

<?php get_template_part('plantilla', 'inicio'); ?>
<?php get_template_part('plantilla', 'proyectos'); ?>
<?php get_template_part('plantilla', 'equipo'); ?>
<?php get_template_part('plantilla', 'contacto'); ?>

<?php get_footer()?>
	